package com.example.myapplication;

public interface ClickListener {
    void onItemClick(int position);
}